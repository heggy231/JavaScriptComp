// Creating a custom object using the Object function
var Gallery = new Object();

window.onload = function () {
  Gallery.Images = ['babyMeekats.jpeg', 'minx.jpeg', 'owl.jpeg'];
  Gallery.CurrentIndex = 0;
  Gallery._loopInterval = setInterval(Gallery.Next, 2500);
};

Gallery.Next = function() {
  // sets base as last ith position of img
  if(Gallery.CurrentIndex < (Gallery.Images.length-1)) {
    // go to the next ith position of img
    Gallery.CurrentIndex++;
  // if you are at the last img 
  } else {
    // resets the CurrentIndex back first img
    Gallery.CurrentIndex = 0;
  }
  // show img
  Gallery.Display();
};

// functionality for previous button
Gallery.Prev = function () {
  // if img is on anything otherthan starting ith
  if(Gallery.CurrentIndex > 0) {
    // move to one less index position
    Gallery.CurrentIndex--;
    // if you are on first img then go to last img
  } else {
    Gallery.CurrentIndex = (Gallery.Images.length - 1);
  }
  Gallery.Display();
};

// renders current img to html
Gallery.Display = function() {
  // access to html id element
  var photoGallery = document.getElementById('photo-gallery');
  // when app loads CurrentIndex is 0 then changes with .Next() method runs
  var currentImage = Gallery.Images[Gallery.CurrentIndex];
  // note: Gallery.Images = ['babyMeekats.jpg', 'minx.jpg', 'owl.jpg'];
  // ex) Gallery.Image[0] = 'babyMeekats.jpg'
  photoGallery.src = "img/" + currentImage; 
};
