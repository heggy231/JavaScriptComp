/**
 * Created by viveksh2 on 4/5/14.
 */
Ext.define('app.model.Users',
    {   extend: 'Ext.data.Model',
        idProperty: 'name', //default to id
         fields: [
             {name: 'name',type:'string'},
             {name:'email'},
             {name:'age',type:'int'},
             {name:'employed',type:'boolean'}
         ],
        capitalizeName:function(){
            this.set('name',Ext.util.Format.uppercase(this.get('name')));
        },
        validations:[
            {type:'length',field:'age',min:2}
        ],
        proxy:{   type:'ajax',   url:'/UCSCExtJSTutorialProject/data/User.json' }

    });

