/**
 * Created by viveksh2 on 4/5/14.
 */
Ext.define('app.views.FormPanelExample', {
    extend : 'Ext.form.Panel',
    xtype : 'formPanelExample',
    config : {
        title:'A Form Panel',
        width:300,height:400,
        url:'/UCSCExtJSTutorialProject/data/success.json',
        items:[{
            xtype: 'container',
            anchor: '100%',
            layout:'column',
            items:[{
                xtype: 'container',
                columnWidth:.5,
                layout: 'anchor',
                items: [{
                    xtype:'textfield',
                    fieldLabel: 'First Name',
                    name: 'first',
                    anchor:'96%',
                    allowBlank:false,
                    blankText: 'Dude you need to fill it'
                }, {
                    xtype:'textfield',
                    fieldLabel: 'Company',
                    name: 'company',
                    anchor:'96%',
                    allowBlank:false
                },
                    {
                        xtype: 'timefield',
                        fieldLabel: 'Time',
                        name: 'time',
                        minValue: '8:00am',
                        maxValue: '6:00pm'
                    }]
            },{
                xtype: 'container',
                columnWidth:.5,
                layout: 'anchor',
                items: [{
                    xtype:'textfield',
                    fieldLabel: 'Last Name',
                    name: 'last',
                    anchor:'100%'
                },{
                    xtype:'textfield',
                    fieldLabel: 'Email',
                    name: 'email',
                    vtype:'email',
                    anchor:'100%'
                }]
            }]
        }, {
            xtype: 'htmleditor',
            name: 'bio',
            fieldLabel: 'Biography',
            height: 200,
            anchor: '100%'
        }],
        buttons:[{
            text:'Submit',
            formBind:true,
            disabled:true,
            handler:function(){
                var form = this.up('form').getForm();
                if(form.isValid()){
                    form.submit({
                        success:function(form,action){Ext.Msg.alert("Success", action.result.msg);
                        },
                        failure:function(form,action){
                            Ext.Msg.alert("Success".action.result.msg);
                        }
                    });  //submit end
                }//form isValid end

            }}]//buttons end
    }
    });