/**
 * Created by viveksh2 on 4/5/14.
 */
Ext.create('Ext.panel.Panel',{

    title:'ExtJS',
    id:'outerPanel',
    xtype: 'traversingPanelExample',
    items:[
        {
            xtype:'textfield',
            id:'outerTextId'
        },{
            xtype:'button',
            text:'Submit',
            id:'buttonId'
        },{
            xtype:'panel',
            id:'innerPanel',
            items:[{
                xtype:'textfield',
                fieldLabel:'Country',
                id:'innerTextId',
                cls:'innerTextCls'
            }]
        }]
});