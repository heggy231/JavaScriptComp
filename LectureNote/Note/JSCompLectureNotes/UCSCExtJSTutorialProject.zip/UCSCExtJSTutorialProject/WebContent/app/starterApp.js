Ext.require([
    'Ext.form.*',
    'Ext.layout.container.Column',
    'Ext.tab.Panel'
]);
Ext.application({
  name :'app',  
requires:['Ext.window.MessageBox',
            'app.extJSBook',
            'app.model.Users',
    'app.views.FormPanelExample'],
  launch:function() {
/*      console.log("Welcome to Ext Starter Tutorial");
      Ext.Msg.alert("Message", "Welcome to Ext Starter Tutorial");

      var book = Ext.create('app.extJSBook');
      book.setTitle("ExtJSStarter");
      book.setPrice("10$");
      book.setAuthor('John');

      console.log("Message 1 - " + book.getTitle());
      Ext.Msg.alert("Message 2- ", book.getTitle());

      var book2 = Ext.create('app.extJSBook', {
          title: 'Ext JS Upgrade',
          author: 'Alex',
          price: '20$'
      });
      Ext.Msg.alert("Message 2 - ", book2.getTitle());*/


      /**
       * Uncomment this code while you discuss the xtypes

      var extjsBookPanel = Ext.create('Ext.panel.Panel', {
          bodyPadding: 5,
          width: 300,
          title: 'extjsBookPanel',
          items: [
              {
                  xtype: 'textfield',
                  fieldLabel: 'Publish date'
              },
              Ext.create('app.extjsButton', {
                  text: 'Custom button instantiated' +
                      'using Ext.create()'
              }),
              {
                  xtype: 'extjsButton',
                  text: 'Custom button instantiated using xtype'            }
          ],
          renderTo: Ext.getBody()
      })
 */

    /*Explanation : Three components have been included inside the item's configuration property. The renderTo property can be either an ID of an element or an element. Ext.getBody() returns the current document body as Ext.Element:

A text field: A text field is instantiated using the xtype text field. Ext JS provides xtype for most of its available components.
Custom button component 1: An app.extjsButton button component is instantiated using the Ext.create() method, as discussed in a previous step.
Custom button component 2: An app.extjsButton button component is instantiated using a custom xtype name. In order for this to work, 
our app.extjsBook class definition needs to have xtype and extend properties specified along with a call to its parent Button class.*/

      /*var viewPortExample = Ext.create("Ext.container.Viewport",{
          layout:'fit',
          items:[{
              xtype:'panel',
              width:300,
              html:'A Panel inside viewport',
              title:'Viewport Panel'
          }]
      })*/

     /* var containerExample = Ext.create("Ext.container.Viewport",{
          layout:'fit',
          items:[{
              xtype:'container',
              // html:'A Panel inside viewport',
              defaults:{
                  margin:'5 5 0 5'
              },
              layout:'vbox',
              items:[{
                  xtype:'textfield',
                  fieldLabel:'Name',
                  *//*
                   * Custom CSS specification. The 'defaults' margin property need to be * commented in order to see the effect of marginBottom.
                   *//*
                  style:{marginBottom:'20px',color:'blue'}

              },{
                  xtype:'button',
                  text:'submit'
              }]
          }]
      });*/

     /* var buttonGroupExample = Ext.create("Ext.container.Viewport",{
          layout:'fit',
          items:[{
              xtype:'buttongroup',
              columns:3,
              title:'Days',
              items:[{xtype:'button',text:"Button No 1"},
                  {xtype:'button',text:"Button No 2"},
                  {xtype:'button',text:"Button No 3"}]}
          ]
      });
*/

      /*Ext.create('Ext.tab.Panel', {
          width: 400,
          height: 400,
          activeTab: 0,
          //layout:'fit',
          //layout:'absolute',
          //x:10, y:10,
          renderTo: document.body,
          dockedItems: [
              {     xtype: 'toolbar', dock: 'bottom', items: [
                  {xtype: 'button', text: 'Docked Button'}
              ]   }
          ],
          items: [

              {
                  title: 'Page 1',
                  html: 'Page1'
              },
              {
                  xtype: 'panel',
                  title: 'Page 2',
                  html: 'Page2'
              }
          ]
      });*/


      /*var cardComp = Ext.create('Ext.container.Container', {
          layout: 'card',
          width: 400,
          height: 400,
          renderTo: document.body,
          items: [
              {     title: 'Page 1', html: 'Page1'   },
              {     title: 'Page 2', html: 'Page2'        }
          ]
      }); //Show the second item visible by uncommenting this line. //cardComp.getLayout().setActiveItem(1);*/

      var extJS_UserStore = Ext.create(
          'Ext.data.Store',
          {   model: 'app.model.Users',
              autoLoad: true
          });

 var tabPanelExample = Ext.create('Ext.panel.Panel',{

     title:'ExtJS',
     id:'outerPanel',
     xtype: 'traversingPanelExample',
     items:[
         {
             xtype:'textfield',
             id:'outerTextId'
         },{
             xtype:'button',
             text:'Submit',
             id:'buttonId'
         },{
             xtype:'panel',
             id:'innerPanel',
             items:[{
                 xtype:'textfield',
                 fieldLabel:'Country',
                 id:'innerTextId',
                 cls:'innerTextCls'
             }]
         }]
 });

      var extJS_UserGrid= Ext.create('Ext.grid.Panel',{
          title:'Ext JS Users List',
          store:extJS_UserStore, //created in previous chapter
          columns:[
              {header:'Name',dataIndex:'name'},
              {header:'Age',dataIndex:'age',width:30},
              {header:'Employed',dataIndex:'employed'},
              {header:'Email',dataIndex:'email',flex:1}   ]
      });


      Ext.create('Ext.tab.Panel',
          {
              layout:'fit',
              dockedItems: [
          {
              xtype: 'toolbar',
              dock: 'bottom',
              items: [
                     {text: 'Docked Button'}
                 ]
          }
            ],
              renderTo: document.body,
              items: [
                {        title: 'Page 1',
                         items: [       extJS_UserGrid         ]
                },
                {
                    title: 'Page 2',
                     items : [tabPanelExample]
                },
                  {
                      title: 'Page 3',
                      xtype : 'formPanelExample'
                  }
      ] });

  }

  });