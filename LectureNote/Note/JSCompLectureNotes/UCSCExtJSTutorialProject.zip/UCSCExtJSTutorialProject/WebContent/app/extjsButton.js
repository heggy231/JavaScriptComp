Ext.define('app.extjsButton',{
  xtype:'extjsButton',
  extend:'Ext.button.Button',
  constructor:function(config){
 //Call Ext.button.Button parent class
    this.callParent(arguments);
  }  
});