Ext.define('app.extJSBook',{
    config:{
        title:'',
        price:'',
        author:''
    },
    constructor : function(config){
        this.initConfig(config);
    }
});